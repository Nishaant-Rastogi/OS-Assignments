#include <stdlib.h>
#include <stdio.h>

void C(){
    printf("\n%s\n","C() is executing.");
    exit(0);
}