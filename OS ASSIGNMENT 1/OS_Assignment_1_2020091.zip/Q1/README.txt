To compile the two parts of Q1 (Q1_a & Q1_b) in phases I have made the makefile.

1.) To straight up get the executables for both Q1_a & Q1_b.
        TYPE: make

2.) To get the preprocessed files (.i files) for both Q1_a & Q1_b.
        TYPE: make preprocess

3.) To get the compiled files or the assembly files (.s files) for both Q1_a & Q1_b.
        TYPE: make compile

4.) To get the object files (.o files) for both Q1_a & Q1_b.
        TYPE: make assemble

5.) To get the executables for both Q1_a & Q1_b after linking.
        TYPE: make link

6.) Now after you have completed the above phases to get the executables. To finally run the files.
        TYPE: make run
